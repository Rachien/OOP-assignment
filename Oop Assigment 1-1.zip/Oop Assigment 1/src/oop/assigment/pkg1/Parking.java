/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.assigment.pkg1;


public class Parking {

    public String area;
    public String name;
    public String space;
    public VehicleType type;
    public Boolean occupied;

    public Parking(String area, String name, String space, VehicleType type, Boolean occupied) {
        this.area = area;
        this.name = name;
        this.space = space;
        this.type = type;
        this.occupied = occupied;
    }

    
    public String getName() {
        return name;
    }

    public String getSpace() {
        return space;
    }

    public VehicleType getType() {
        return type;
    }

    public Boolean getOccupied() {
        return occupied;
    }

    public void setOccupied(Boolean occupied) {
        this.occupied = occupied;
    }

}
