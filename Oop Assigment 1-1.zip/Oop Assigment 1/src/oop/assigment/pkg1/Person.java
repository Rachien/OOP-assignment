/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.assigment.pkg1;

import java.util.ArrayList;


public class Person implements Data {

    public String id;
    public String password;
    public String username;
    public ArrayList<Vehicle> vehicles = new ArrayList<Vehicle>();


    public Person(String id, String password, String username) {
        this.id = id;
        this.password = password;
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ArrayList<Vehicle> getVehicles() {
        return vehicles;
    }

    public void setVehicles(ArrayList<Vehicle> vehicles) {
        this.vehicles = vehicles;
    }
    


    @Override
    public String data() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
