/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.assigment.pkg1;

import java.util.ArrayList;
import java.util.Scanner;

public class UKMParking {

    static ArrayList<Person> users = new ArrayList<Person>();
    static ArrayList<Parking> parkings = new ArrayList<Parking>();
    static ArrayList<Vehicle> veh = new ArrayList<Vehicle>();


    public static void main(String[] args) {
        parkings.add(new Parking("Floor 1", "B1", "1m", VehicleType.Bus, false));
        parkings.add(new Parking("Floor 1", "C1", "1m", VehicleType.Car, false));
        parkings.add(new Parking("Floor 1", "L1", "1m", VehicleType.Lorry, false));
        parkings.add(new Parking("Floor 1", "C2", "1m", VehicleType.Car, false));

        landingPage();

    }

    static void landingPage() {

        Scanner s = new Scanner(System.in);
        int c;
        do {
            System.out.println("*** NUST PARKING system ***");
            System.out.println("          TOWN                                          ");
            System.out.println("         WINDHOEK                                      ");
            System.out.println("*****************************************************************************************");

            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Quit");

            System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            System.out.print(" Enter choice");
            c = s.nextInt();
            switch (c) {
                case 1://login menu here
                    users.add(register());
                    Profile();

                    break;
                case 2:
                    if (login()) {
                        Profile();

                    } else {
                        System.exit(0);

                    }
                    break;

                case 3: //exit from system
                    System.exit(0);

                    break;

                default:
                    System.out.println("invalid choice");
            }
        } while (c != 3);
    }

    public static Person register() {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter username:");
        String usn = s.next();
        System.out.println("Enter Password :");
        String pass = s.next();
        System.out.println("Enter ID :");
        String id = s.next();

        Person p1 = new Person(id, usn, pass);

        return p1;

    }

    public static boolean login() {
        Scanner s = new Scanner(System.in);
        System.out.print("username:");
        String usn = s.next();
        System.out.println("Password :");
        int pass = s.nextInt();

        if (usn.equals("jfiina") && pass == 1234) {

            System.out.println("user has been authenticated");
            return true;

        } else {
            System.out.println("Wrong details");
            return false;
        }

    }

    public static void Profile() {
        Scanner s = new Scanner(System.in);
        int c;
        do {
            System.out.println("*** WELCOME TO YOUR PROFILE PAGE ***");
            System.out.println("               TOWN                                          ");
            System.out.println("             WINDHOEK                                      ");
            System.out.println("*****************************************************************************************");
            System.out.println("     ");

            System.out.println("1. Add Vehicle");
            System.out.println("2. view vehicle");
            System.out.println("3. view Registered  Users");
            System.out.println("4. view Parkings");
            System.out.println("5. Quit");

            System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            System.out.print(" Enter choice");
            c = s.nextInt();
            switch (c) {
                case 1://login menu here

                    System.out.print("how many vehicle:");
                    int cch = s.nextInt();

                    for (int i = 0; i < cch; i++) {
                        System.out.print("name:");
                        String name = s.next();
                        System.out.println("plat no :");
                        String plat = s.next();
                        System.out.print("type:");
                        String typ = s.next();
                        
                        //composition relationship, vehicles can only exist if users exist
                        users.get(0).vehicles.add(new Vehicle(name, plat, VehicleType.Car));

                    }

                    break;
                case 2://view vehicle
                    for (Person p : users) {
                        for (Vehicle v : p.vehicles) {
                            System.out.println("Name : " + v.vehicle + "     Plat Number : " + v.plat_no + "      Type: " + v.type);
                        }
                    }

                    break;
                case 3://view registered users
                    for (Person p : users) {
                        System.out.println("ID : " + p.id + "     Username : " + p.username);
                    }

                    break;

                case 4: //view parkings
                    for (Parking p : parkings) {
                        System.out.println("Area : " + p.area + "     Name : " + p.name + "      Space: " + p.space
                                + "      Type: " + p.type + "        Occupied: " + p.occupied);
                    }

                    break;
                case 5: //exit from system
                    System.exit(0);

                    break;

                default:
                    System.out.println("invalid choice");
            }
        } while (c != 3);

    }
}
