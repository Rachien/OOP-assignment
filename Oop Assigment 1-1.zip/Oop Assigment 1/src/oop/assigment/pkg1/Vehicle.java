/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.assigment.pkg1;

import java.util.ArrayList;
import java.util.Scanner;


class Vehicle implements Data {

    public String vehicle;
    public String plat_no;
    public VehicleType type;
   

    public Vehicle() {
    }

    public Vehicle(String vehicle, String plat_no, VehicleType type) {
        this.vehicle = vehicle;
        this.plat_no = plat_no;
        this.type = type;
    }

    public String getVehicle() {
        return vehicle;
    }

    public String getPlat_no() {
        return plat_no;
    }

    @Override
    public String toString() {
        return "Vehicle{" + "vehicle=" + vehicle + ", plat_no=" + plat_no + ", type=" + type + '}';
    }

    @Override
    public String data() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    


    

}
